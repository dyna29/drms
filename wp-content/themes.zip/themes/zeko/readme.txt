=== Zeko ===

* by Anariel Design, http://www.anarieldesign.com

== Credits ==

* Based on Components http://components.underscores.me/, (C) 2015-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html) and Lodestar WordPress Theme by Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
* ScrollTo https://github.com/flesler/jquery.scrollTo (C) 2007-2016 Ariel Flesler [MIT](http://opensource.org/licenses/MIT)
* Genericons icon font http://www.genericons.com (C) 2016 Automattic [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Screenshot images licensed under CC0 Public Domain (http://creativecommons.org/publicdomain/zero/1.0/deed.en):
** https://pixabay.com/
** https://unsplash.com/

== Licensing ==

Zeko WordPress theme, Copyright 2017 Anariel Design
Zeko is distributed under the terms of the GNU GPL

1.0.9 - October 17, 2017

- small fix for for the TGM and Zeko Custom Post Type slug

1.0.8 - October 12, 2017

- small fix for the archive page

1.0.7 - October 5, 2017

- added new options inside the Customizer for the Grid Template - child page title link and featured image link

1.0.6 - September 7, 2017
- added caption background color for the smaller devices inside the Theme Options > Front Page Hero Image

1.0.5 - July 9, 2017

- fix for the select element inside the style.css
- added new page template with right sidebar
- new .pot file


1.0.4 - July 05, 2017

- added support for the PeepSo plugin - social networking plugin for WordPress
- WPML compatibility - new wpml-config.xml file

1.0.3 - July 03, 2017

- small fix for the copyright text inside the Customizer 
- added mobile menu options inside the Customizer

1.0.2 - June 30, 2017

- small fixes inside the style.css file
- added post thumbnails image size for the recent post on the front page and child pages on the grid page


1.0.1 - June 26, 2017

- small fix inside the style.css file for the hover button

